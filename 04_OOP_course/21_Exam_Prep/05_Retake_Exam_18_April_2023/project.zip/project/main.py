count = 0

vehicles_to_repair = ["car1", "car2", "car3"][:count]
print(vehicles_to_repair)