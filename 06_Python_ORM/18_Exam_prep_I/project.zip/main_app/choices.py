from django.db import models


class MovieGenreChoices(models.TextChoices):
    ACTION = 'Action', 'Action',
    COMEDY = 'Comedy', 'Comedy',
    DRAMA = 'Drama', 'Drama',
    OTHER = 'Other', 'Other',
